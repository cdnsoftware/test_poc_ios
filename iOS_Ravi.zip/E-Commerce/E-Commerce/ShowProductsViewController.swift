//
//  ShowProductsViewController.swift
//  Products
//
//  Created by Ravi Patidar on 30/09/24.

import UIKit
import Combine

class ShowProductsViewController: UIViewController, UITextFieldDelegate {
    
    var products: [ProductDetail] = [] // Filtered products
    var unfilterdproductsArray: [ProductDetail] = [] // Original products
    var cancellables = Set<AnyCancellable>()
    
    @IBOutlet weak var searchTextField: UITextField! {
        didSet {
            self.searchTextField.delegate = self
        }
    }
    @IBOutlet var productTableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchProducts()
        // Set table view delegates
        productTableview.delegate = self
        productTableview.dataSource = self
    }
    
    // Action for search text field when text changes
    @IBAction func searchEditingChanged(_ sender: UITextField) {
        if let searchText = sender.text, searchText.isEmpty {
            // If search text is empty, show all products
            self.products = self.unfilterdproductsArray
        } else {
            // Filter the products based on search text
            self.products = unfilterdproductsArray.filter { product in
                let searchText = sender.text?.lowercased() ?? ""
                // Search in productId, name, or price
                return product.productId?.lowercased().contains(searchText) ?? false ||
                       product.name?.lowercased().contains(searchText) ?? false ||
                       String(product.price ?? 0.0).contains(searchText)
            }
        }
        // Reload table view with filtered data
        self.productTableview.reloadData()
    }
    
    // Cancel search action (optional, to clear search field)
    @IBAction func BtnCancel(sender: UIButton) {
        searchTextField.text = ""
        self.products = self.unfilterdproductsArray
        self.productTableview.reloadData()
    }
}

//MARK: API Call
extension ShowProductsViewController {
    // Fetch products from the API
    private func fetchProducts() {
        NetworkManager.shared.fetchProducts()
            .sink(receiveCompletion: { completion in
                switch completion {
                case .finished:
                    print("Finished fetching products")
                case .failure(let error):
                    print("Failed to fetch products: \(error.localizedDescription)")
                }
            }, receiveValue: { [weak self] products in
                self?.unfilterdproductsArray = products // Save unfiltered products
                self?.products = products // Display all products initially
                self?.productTableview.reloadData()
            })
            .store(in: &cancellables)
    }
}
extension ShowProductsViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
        let  product = products[indexPath.row]
        
        cell.productName.text = "Name: \(product.name ?? "" )"
        cell.productID.text = "Price: \(product.productId ?? "")"
        cell.price.text = "Avg Rating: \(product.price ?? 0.0)"
        cell.productImgView.layer.shadowColor =  UIColor.darkGray.cgColor
        cell.productImgView.layer.shadowOffset = CGSize(width: 0, height: 0)
        cell.productImgView.layer.shadowOpacity = 0.9
        cell.productImgView.layer.shadowRadius = 3.0
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let  product = products[indexPath.row]
        let vc = self.storyboard?.instantiateViewController(identifier: "ProductDetailViewController") as! ProductDetailViewController
        vc.productID =  product.productId ?? ""
        vc.productName = product.name ?? ""
        vc.productPrice = product.price ?? 0.0
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
class ProductTableViewCell: UITableViewCell {
    @IBOutlet var productName: UILabel!
    @IBOutlet var productID: UILabel!
    @IBOutlet var price: UILabel!
    @IBOutlet var stackView:UIStackView!
    @IBOutlet var productImgView:UIView!
    @IBOutlet var mainView:UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        mainView.layer.cornerRadius = 16
        mainView.layer.masksToBounds = true
        
        stackView.layer.cornerRadius = 16
        stackView.layer.masksToBounds = true
        
        productImgView.layer.cornerRadius = 35
        productImgView.layer.masksToBounds = true
    }
}

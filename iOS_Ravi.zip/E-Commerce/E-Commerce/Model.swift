//
//  Model.swift
//  Products
//
//  Created by Ravi Patidar on 30/09/24.
//

import Foundation

// MARK: - ProductResponse
struct Productlist: Codable {
    let productList: [ProductData]?
}

// MARK: - Product
struct ProductData: Codable {
    let productId: String?
    let name: String?
    let price: Double?
}






// MARK: - ProductDetailResponse
struct ProductResponse: Codable {
    let products: [ProductDetail]?
    let message: String?
}

// MARK: - Product
struct ProductDetail: Codable {
    let productId: String?
    let name: String?
    let price: Double?
    let reviews: [Review]?
}

// MARK: - Review
struct Review: Codable {
    let reviewerName: String?
    let rating: Double?
    let comment: String?
}


//
//  ApiManager.swift
//  Products
//
//  Created by Ravi Patidar on 30/09/24.
//

import Foundation
import Foundation
import Combine

class NetworkManager {
    static let shared = NetworkManager() // Singleton instance
    private var cancellables = Set<AnyCancellable>()
    
    let productURL = URL(string: "https://run.mocky.io/v3/e208e06c-c8db-4d6d-a33a-9eae3ae4955c")! // Update to your provided URL
    
    let productDetailURL = URL(string: "https://run.mocky.io/v3/b40a5a18-3a52-45b4-90bc-943977aee77e")! // Update to your provided URL
    
    
    // Function to fetch products from the API
    func fetchProducts() -> AnyPublisher<[ProductDetail], Error> {
        URLSession.shared.dataTaskPublisher(for: productDetailURL)
            .tryMap { (data, response) -> Data in
                // Ensure the response is valid and within the 200-299 range
                guard let httpResponse = response as? HTTPURLResponse, (200..<300).contains(httpResponse.statusCode) else {
                    throw URLError(.badServerResponse)
                }
                return data
            }
            .decode(type: ProductResponse.self, decoder: JSONDecoder()) // Decode into ProductResponse
            .map { $0.products ?? [] } // Extract the products array
            .receive(on: DispatchQueue.main) // Ensure that we receive the data on the main thread
            .eraseToAnyPublisher()
    }
    
    func fetchProductDetails() -> AnyPublisher<[ProductDetail], Error> {
        URLSession.shared.dataTaskPublisher(for: productDetailURL)
            .tryMap { (data, response) -> Data in
                // Ensure the response is valid and within the 200-299 range
                guard let httpResponse = response as? HTTPURLResponse, (200..<300).contains(httpResponse.statusCode) else {
                    throw URLError(.badServerResponse)
                }
                return data
            }
            .decode(type: ProductResponse.self, decoder: JSONDecoder()) // Decode into ProductResponse
            .map { $0.products ?? [] } // Extract the products array
            .receive(on: DispatchQueue.main) // Ensure that we receive the data on the main thread
            .eraseToAnyPublisher()
    }

}


import UIKit
import Combine

class ProductDetailViewController: UIViewController {
    
    var productDetail: [ProductDetail]? // Assuming one product's details
    var cancellables = Set<AnyCancellable>()
    
    @IBOutlet var productDetailTableView: UITableView!
    @IBOutlet var productNameLabel: UILabel!
    @IBOutlet var productPriceLabel: UILabel!
    
    var productID = "" // This should be passed from the previous screen
    var productName = ""
    var productPrice = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set table view delegates
        productDetailTableView.delegate = self
        productDetailTableView.dataSource = self
        
        // Set initial product data
        self.productNameLabel.text = productName
        self.productPriceLabel.text = "\(productPrice)"
        
        // Fetch product details from the API
        fetchProductDetail()
    }
    
    @IBAction func BackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

//MARK: API Calling
extension ProductDetailViewController {
    private func fetchProductDetail() {
        NetworkManager.shared.fetchProductDetails()
            .receive(on: DispatchQueue.main) // Ensure it runs on main thread
            .sink(receiveCompletion: { completion in
                switch completion {
                case .finished:
                    print("Finished fetching product details")
                case .failure(let error):
                    print("Failed to fetch product details: \(error.localizedDescription)")
                }
            }, receiveValue: { [weak self] product in
                guard let self = self else { return }
                
                // Check if product details are available
                print("Fetched product: \(product)")
                self.productDetail = product
                
                // Reload table view on the main thread after updating the data
                self.productDetailTableView.reloadData()
            })
            .store(in: &cancellables)
    }
}

//MARK: UITableViewDelegate and UITableViewDataSource
extension ProductDetailViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
            return 1 // Return the number of products
        }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            guard let product = productDetail?[section] else { return 0 }
            let count = product.reviews?.count ?? 0 // Return the number of reviews for the product
            print("Number of reviews: \(count)")
            return count
        }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductDetailTableViewCell", for: indexPath) as! ProductDetailTableViewCell
        guard let product = productDetail?[indexPath.section] else { return cell }

        let productid =  productDetail?[indexPath.section].productId
        let review = product.reviews?[indexPath.row]
        if productid == productID{
            cell.reviewerName.text = "Reviewer: \(review?.reviewerName ?? "Anonymous")"
                cell.rating.text = "Rating: \(review?.rating ?? 0.0)"
                cell.comment.text = "Comment: \(review?.comment ?? "")"
        }
        
        return cell
    }
}

//MARK: Custom TableViewCell
class ProductDetailTableViewCell: UITableViewCell {
    @IBOutlet var reviewerName: UILabel!
    @IBOutlet var rating: UILabel!
    @IBOutlet var comment: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

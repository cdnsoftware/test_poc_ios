//
//  APIManger.swift
//  E-Commerce-App
//
//  Created by Vinit Shrivastav on 30/09/24.
//
import Foundation
import Combine

class APIService {
    
    private var cancellables = Set<AnyCancellable>()

    func getProducts() -> AnyPublisher<[Product], Error> {
        if NetworkManager.isNetworkAvailable() {
            let url = URL(string: "https://run.mocky.io/v3/e208e06c-c8db-4d6d-a33a-9eae3ae4955c")!
            
            return URLSession.shared.dataTaskPublisher(for: url)
                .map { $0.data }
                .decode(type: ProductResponse.self, decoder: JSONDecoder())
                .map { $0.productList ?? [] }
                .eraseToAnyPublisher()
        } else {
            return Fail(error: URLError(.notConnectedToInternet))
                .eraseToAnyPublisher()
        }
    }
    
    func getReviews() -> AnyPublisher<[ProductReview], Error> {
        if NetworkManager.isNetworkAvailable() {
            let url = URL(string: "https://run.mocky.io/v3/b40a5a18-3a52-45b4-90bc-943977aee77e")!
            
            return URLSession.shared.dataTaskPublisher(for: url)
                .map { $0.data }
                .decode(type: ProductReviewResponse.self, decoder: JSONDecoder())
                .map { $0.products ?? [] }
                .eraseToAnyPublisher()
        } else {
            return Fail(error: URLError(.notConnectedToInternet))
                .eraseToAnyPublisher()
        }
    }
}



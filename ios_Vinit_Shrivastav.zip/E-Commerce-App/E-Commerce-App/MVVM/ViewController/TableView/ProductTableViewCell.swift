//
//  ProductTableViewCell.swift
//  E-Commerce-App
//
//  Created by Vinit Shrivastav on 30/09/24.
//

import UIKit

class ProductTableViewCell: UITableViewCell {

    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblRating: UILabel!
    
    @IBOutlet weak var imgPreview: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(with i: MergedProduct) {
        lblTitle.text = "Product Name : " + (i.product.name ?? "")
        lblRating.text = "Rating - " + String(format: "%.2f", i.averageRating)
    }
}

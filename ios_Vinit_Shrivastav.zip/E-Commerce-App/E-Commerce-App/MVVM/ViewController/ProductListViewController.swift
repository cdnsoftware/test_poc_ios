//
//  ViewController.swift
//  E-Commerce-App
//
//  Created by Vinit Shrivastav on 30/09/24.
//

import UIKit
import Combine

class ProductListViewController: UIViewController {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    private var apiService = APIService()
    private var cancellables = Set<AnyCancellable>()
    
    private var mergedProducts: [MergedProduct] = [] // Stores filtered products with reviews
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Products"
        setupTableView()
        fetchProductsAndReviews()
    }
    
    private func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "ProductTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductTableViewCell")
    }
    
    func fetchProductsAndReviews() {
        let productsPublisher = apiService.getProducts()
        let reviewsPublisher = apiService.getReviews()
        
        productsPublisher
            .flatMap { products in
                reviewsPublisher
                    .map { reviews in
                        self.mergeProductsWithReviews(products: products, reviews: reviews)
                    }
            }
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
                switch completion {
                case .finished:
                    print("Finished fetching and merging data.")
                case .failure(let error):
                    print("API Error: \(error.localizedDescription)")
                }
            }, receiveValue: { [weak self] mergedProducts in
                self?.mergedProducts = mergedProducts.filter { $0.averageRating >= 4.0 }
                self?.tableView.reloadData()
            })
            .store(in: &cancellables)
    }
    
    private func mergeProductsWithReviews(products: [Product], reviews: [ProductReview]) -> [MergedProduct] {
        var mergedProducts: [MergedProduct] = []
        
        for product in products {
            if let productId = product.productId {
                let matchingReviews = reviews.first { $0.productId == productId }?.reviews ?? []
                
                let totalRating = matchingReviews.reduce(0) { $0 + ($1.rating ?? 0) }
                let averageRating = matchingReviews.isEmpty ? 0 : Double(totalRating) / Double(matchingReviews.count)
                
                if !matchingReviews.isEmpty {
                    let mergedProduct = MergedProduct(product: product, reviews: matchingReviews, averageRating: averageRating)
                    mergedProducts.append(mergedProduct)
                }
            }
        }
        
        return mergedProducts
    }
}

// MARK: - UITableViewDelegate & UITableViewDataSource
extension ProductListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mergedProducts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
        let mergedProduct = mergedProducts[indexPath.row]
        cell.configure(with: mergedProduct)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Handle cell selection if needed
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

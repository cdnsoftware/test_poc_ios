//
//  ProductReviewsViewController.swift
//  E-Commerce-App
//
//  Created by Vinit Shrivastav on 30/09/24.
//

import Foundation
import UIKit

class ProductReviewsViewController: UIViewController  {


    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.title = "Reviews"
    }

}

//
//  ListModel.swift
//  E-Commerce-App
//
//  Created by Vinit Shrivastav on 30/09/24.
//

import Foundation


struct ProductResponse: Codable {
    var productList: [Product]?
}

struct Product: Codable {
    var productId: String?
    var name: String?
    var price: Double?
}


struct ProductReviewResponse: Codable {
    var products: [ProductReview]?
    var message: String?
}

struct ProductReview: Codable {
    var productId: String?
    var name: String?
    var price: Double?
    var reviews: [Review]?
}

struct Review: Codable {
    var reviewerName: String?
    var rating: Int?
    var comment: String?
}
struct MergedProduct {
    var product: Product
    var reviews: [Review]
    var averageRating: Double
}



////
////  ListViewModel.swift
////  E-Commerce-App
////
////  Created by Vinit Shrivastav on 30/09/24.
////
//
//import Foundation
//import Combine
//
//class ProductViewModel: NSObject {
//
//    @Published var productsWithReviews: [(product: Product, reviews: [Review])] = []
//    var cancellables = Set<AnyCancellable>()
//    private let dataService = APIService()
//
//    func fetchData() {
//        let productsPublisher = dataService.fetchProducts()
//        let reviewsPublisher = dataService.fetchReviews()
//
//        // Combine both publishers
//        Publishers.Zip(productsPublisher, reviewsPublisher)
//            .map { products, reviews in
//                // Associate products with their reviews
//                return products.compactMap { product in
//                    let associatedReviews = reviews.filter { $0.productId == product.productId }
//                    let averageRating = associatedReviews.compactMap { $0.rating }.reduce(0, +) / max(1, associatedReviews.count)
//                    return averageRating >= 4 ? (product, associatedReviews) : nil
//                }
//            }
//            .receive(on: DispatchQueue.main)
//            .sink(receiveCompletion: { completion in
//                if case let .failure(error) = completion {
//                    print("Error: \(error)")
//                }
//            }, receiveValue: { [weak self] productsWithReviews in
//                self?.productsWithReviews = productsWithReviews
//            })
//            .store(in: &cancellables)
//    }
//}

//
//  sampleJson.swift
//  E-Commerce-App
//
//  Created by Vinit Shrivastav on 30/09/24.
//

import Foundation




// MARK: -  Product
//
//
//{
//  "statusCode": 200,
//  "responseData": [
//    {
//      "productId": 1,
//      "name": "Product A",
//      "price": 29.99
//    },
//    {
//      "productId": 2,
//      "name": "Product B",
//      "price": 49.99
//    },
//    {
//      "productId": 3,
//      "name": "Product C",
//      "price": 19.99
//    }
//  ]
//}
//
//
//
//// MARK: - Reviews
//
//{
//  "statusCode": 200,
//  "responseData": [
//    {
//      "productId": 1,
//      "reviewerName": "Alice",
//      "rating": 5,
//      "comment": "Great product!"
//    },
//    {
//      "productId": 1,
//      "reviewerName": "Bob",
//      "rating": 4,
//      "comment": "Very useful."
//    },
//    {
//      "productId": 2,
//      "reviewerName": "Charlie",
//      "rating": 3,
//      "comment": "Okay product."
//    },
//    {
//      "productId": 3,
//      "reviewerName": "David",
//      "rating": 4,
//      "comment": "Good value for money."
//    }
//  ]
//}

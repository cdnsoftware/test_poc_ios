//
//  ProductsViewController.swift
//  E-CommerceSystem
//
//  Created by Priyanka  Singhnath on 30/09/24.
//
import UIKit
import Combine

class ProductListViewController: UIViewController {

    // MARK: - IB Outlets
    @IBOutlet weak var enterRatingTextField: UITextField!
    @IBOutlet weak var productsTableView: UITableView!
    @IBOutlet var filterView: UIView!

    // MARK: - ViewModel
    private var viewModel = ProductViewModel()

    // MARK: - Combine Cancellables
    private var cancellables = Set<AnyCancellable>()

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        bindViewModel()
    }

    // MARK: - UI Setup
    private func setupUI() {
        title = "Product List"
        view.backgroundColor = .white
        
        // Table view setup
        productsTableView.delegate = self
        productsTableView.dataSource = self
        productsTableView.register(UINib(nibName: "ProductsTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductsTableViewCell")
    }

    // MARK: - ViewModel Binding
    private func bindViewModel() {
        // Observe changes to products with reviews
        viewModel.$productsWithReviews
            .receive(on: DispatchQueue.main)
            .sink { [weak self] products in
                self?.productsTableView.reloadData() // Reload the table view
            }
            .store(in: &cancellables)
        
        // Observe error messages and show alert
        viewModel.$errorMessage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] errorMessage in
                if let message = errorMessage {
                    self?.showErrorAlert(message: message)
                }
            }
            .store(in: &cancellables)
    }

    // MARK: - IBActions
    @IBAction func doneButtonAction(_ sender: Any) {
        guard let ratingText = enterRatingTextField.text, let rating = Double(ratingText) else {
            showErrorAlert(message: "Please enter a valid rating.")
            return
        }
        
        // Update the view model with the new rating
        viewModel.fetchProductData(avgrRating: rating)
        filterView.removeFromSuperview()
    }

    @IBAction func dismissFilterView(_ sender: Any) {
        filterView.removeFromSuperview()
    }

    @IBAction func filterButtonAction(_ sender: Any) {
        filterView.frame = view.bounds
        view.addSubview(filterView)
    }

    // MARK: - Error Handling
    private func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

extension ProductListViewController: UITableViewDataSource, UITableViewDelegate {
    // MARK: - UITableViewDataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.productsWithReviews.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ProductsTableViewCell", for: indexPath) as? ProductsTableViewCell else {
            return UITableViewCell()
        }
        
        let productWithReviews = viewModel.productsWithReviews[indexPath.row]
        cell.setData(model: productWithReviews)
        return cell
    }

    // MARK: - UITableViewDelegate Methods
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let productWithReviews = viewModel.productsWithReviews[indexPath.row]
        
        guard let scene = UIStoryboard(name: "Main", bundle: .main)
            .instantiateViewController(withIdentifier: "ProductDetailViewController") as? ProductDetailViewController else { return }
        
        // Pass data to the details view controller
        scene.reviews = productWithReviews.reviews
        scene.productName = productWithReviews.product.name ?? ""
        
        let averageRating = productWithReviews.averageRating ?? 0
        let formattedRating = String(format: "%.1f", averageRating)
        scene.avgRatings = "Avg Rating: \(formattedRating)"
        
        scene.prodImage = productWithReviews.product.avatarUrl ?? ""
        scene.price = "$ \(productWithReviews.product.price ?? 0.0)"
        
        // Navigate to the details screen
        navigationController?.pushViewController(scene, animated: true)
    }
}

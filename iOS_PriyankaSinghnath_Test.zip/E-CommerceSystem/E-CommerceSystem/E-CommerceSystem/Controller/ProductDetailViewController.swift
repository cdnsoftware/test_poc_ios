//
//  ProductDetailViewController.swift
//  E-CommerceSystem
//
//  Created by Priyanka  Singhnath on 30/09/24.
//

import UIKit
import SDWebImage

class ProductDetailViewController: UIViewController {

    @IBOutlet weak var productNameLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var avgRatingsLabel: UILabel!
    @IBOutlet weak var productiImage: UIImageView!
    @IBOutlet weak var reviewTableView: UITableView! {
        didSet {
            self.reviewTableView.delegate = self
            self.reviewTableView.dataSource = self
        }
    }

    var reviews: [Review] = [] // Array to hold reviews
    var productName = ""
    var avgRatings = ""
    var prodImage = ""
    var price = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.priceLabel.text = price
        self.productNameLabel.text = productName
        self.avgRatingsLabel.text = avgRatings
        if let url = URL(string: prodImage) {
            // self.productiImage.sd_setImage(with: url)
        }
        reviewTableView.register(UITableViewCell.self, forCellReuseIdentifier: "ReviewCell")
    }

    @IBAction func backButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension ProductDetailViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reviews.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReviewCell", for: indexPath)
        let review = reviews[indexPath.row]
        
        // Configure the cell with review data
        cell.textLabel?.text = "\(review.reviewerName ?? "") - Rating: \(review.rating ?? 0 )\n\(review.comment ?? "")"
        cell.textLabel?.numberOfLines = 0 // Allow multiple lines for comments
        
        return cell
    }
}


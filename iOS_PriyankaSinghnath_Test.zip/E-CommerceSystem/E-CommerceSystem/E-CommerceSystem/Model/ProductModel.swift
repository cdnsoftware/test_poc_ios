//
//  ProductModel.swift
//  E-CommerceSystem
//
//  Created by Priyanka  Singhnath on 30/09/24.
//

import Foundation

struct ProductWithReviews: Codable {
    let product: Product
    let reviews: [Review]
}

struct Product: Codable {
    let productId: String?
    let name: String?
    let avatarUrl: String?
    let price: Double?
}

struct ProductListResponse: Codable {
    let productList: [Product]? // This corresponds to the "productList" key in your JSON
}

struct Review: Codable {
    let reviewerName: String?
    let rating: Int?
    let comment: String?
    var productID: String? // Ensure this property exists
}

struct ProductReviewsResponse: Codable {
    let products: [ProductReview]?
    let message: String?
}

struct ProductReview: Codable {
    let productId: String?
    let reviews: [Review]?

    // Method to create reviews with the associated productId
    func reviewsWithProductId() -> [Review] {
        guard let productId = productId, let reviews = reviews else {
            return []
        }

        return reviews.map { review in
            var modifiedReview = review
            modifiedReview.productID = productId
            return modifiedReview
        }
    }
}

extension ProductWithReviews {
    var averageRating: Double? {
        guard !reviews.isEmpty else { return nil }
        let totalRating = reviews.compactMap { $0.rating }.reduce(0, +)
        return Double(totalRating) / Double(reviews.count)
    }
}

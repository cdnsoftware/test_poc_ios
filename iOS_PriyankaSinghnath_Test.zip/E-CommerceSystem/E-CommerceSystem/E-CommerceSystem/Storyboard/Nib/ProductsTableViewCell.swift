//
//  ProductsTableViewCell.swift
//  E-CommerceSystem
//
//  Created by Priyanka  Singhnath on 30/09/24.
//

import UIKit
import SDWebImage

class ProductsTableViewCell: UITableViewCell {

    //MARK: Outlets
    @IBOutlet private weak var productImage: UIImageView!
    @IBOutlet private weak var productNameLabel: UILabel!
    @IBOutlet private weak var avgRatingsLabel: UILabel!
    @IBOutlet private weak var priceLabel: UILabel!

    //MARK: setData
    func setData(model: ProductWithReviews) {
        if let url = URL(string: model.product.avatarUrl ?? "") {
          //  self.productImage.sd_setImage(with: url)
        }
        self.productNameLabel.text = model.product.name

        let averageRating = model.averageRating ?? 0
        let formattedRating = String(format: "%.1f", averageRating)

        self.avgRatingsLabel.text = "Avg Rating: \(formattedRating)"
        self.priceLabel.text = "$ \(model.product.price ?? 0.0)"
    }

}

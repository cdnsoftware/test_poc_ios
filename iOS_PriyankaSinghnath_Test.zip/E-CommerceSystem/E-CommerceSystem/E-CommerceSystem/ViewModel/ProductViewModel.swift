//
//  ProductViewModel.swift
//  E-CommerceSystem
//
//  Created by Priyanka  Singhnath on 30/09/24.
//

import Combine
import Foundation
import UIKit

class ProductViewModel: ObservableObject {
    @Published var productsWithReviews: [ProductWithReviews] = [] // Final combined product data with reviews
    @Published var errorMessage: String? = nil // For error messages, if any occur
    
    private var cancellables = Set<AnyCancellable>() // Store Combine subscriptions
    
    init() {
        fetchProductData(avgrRating: 4.0)
    }
    
    func fetchProductData(avgrRating: Double) {
        
        
        // Step 1: Fetch products and reviews concurrently using `Publishers.Zip`
        let productAndReviewPublisher = Publishers.Zip(fetchProducts(), fetchReviews())
        
        // Step 2: Map over the fetched results and combine them into `ProductWithReviews`
        productAndReviewPublisher
            .map { (products: [Product], reviews: [Review]) -> [ProductWithReviews] in
                products.map { product in
                    let productReviews = reviews.filter { review in
                        review.productID == product.productId // Ensure this matches the Product ID field
                    }
                    return ProductWithReviews(product: product, reviews: productReviews)
                }
            }
            .sink(receiveCompletion: { completion in
                switch completion {
                case .failure(let error):
                    self.errorMessage = "Failed to fetch product data: \(error.localizedDescription)"
                case .finished:
                    print("Finished fetching product data")
                }
            }, receiveValue: { [weak self] (combinedProducts: [ProductWithReviews]) in
                self?.productsWithReviews = combinedProducts.filter {
                    ($0.averageRating ?? 0.0) >= avgrRating //$0.reviews.isEmpty ||
                }
            })
            .store(in: &cancellables)
    }
    
    private func fetchProducts() -> AnyPublisher<[Product], Error> {

        guard let url = URL(string: "https://run.mocky.io/v3/6e25a5fb-9ac3-40d3-b9df-970eb3a03c97") else {
            return Fail(error: URLError(.badURL)).eraseToAnyPublisher()
        }
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .decode(type: ProductListResponse.self, decoder: JSONDecoder())
            .map { $0.productList ?? [] } // Extract productList array from response
            .eraseToAnyPublisher()
    }
    
    private func fetchReviews() -> AnyPublisher<[Review], Error> {
        guard let url = URL(string: "https://run.mocky.io/v3/b40a5a18-3a52-45b4-90bc-943977aee77e") else {
            return Fail(error: URLError(.badURL)).eraseToAnyPublisher()
        }
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .decode(type: ProductReviewsResponse.self, decoder: JSONDecoder())
            .map { response in
                return response.products?.flatMap { $0.reviewsWithProductId() } ?? []
            }
            .eraseToAnyPublisher()
    }
}

class CustomUIView: UIView {
    @IBInspectable var cornerRadius: CGFloat {
        set {
            self.layer.cornerRadius = newValue
        }
        get {
            return self.layer.cornerRadius
        }
    }}

class CustomUIButton: UIButton {
    @IBInspectable var cornerRadius: CGFloat {
        set {
            self.layer.cornerRadius = newValue
        }
        get {
            return self.layer.cornerRadius
        }
    }}
